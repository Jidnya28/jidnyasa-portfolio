import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { useState } from "react";
import { Database, BarChart3, Code2, Brain, Cloud, Wrench } from "lucide-react";

export function Technologies() {
  const [activeCategory, setActiveCategory] = useState("all");

  const categories = [
    { id: "all", name: "All Technologies", icon: Wrench },
    { id: "data", name: "Data Analysis", icon: BarChart3 },
    { id: "databases", name: "Databases", icon: Database },
    { id: "programming", name: "Programming", icon: Code2 },
    { id: "ml", name: "Machine Learning", icon: Brain },
    { id: "cloud", name: "Cloud & Tools", icon: Cloud },
    { id: "web", name: "Web Development", icon: Code2 }
  ];

  const technologies = [
    // Data Analysis
    { name: "Power BI", category: "data", level: "Expert", color: "from-yellow-400 to-orange-500" },
    { name: "Tableau", category: "data", level: "Advanced", color: "from-blue-400 to-blue-600" },
    { name: "Excel", category: "data", level: "Expert", color: "from-green-400 to-green-600" },
    { name: "Google Analytics", category: "data", level: "Intermediate", color: "from-orange-400 to-red-500" },
    
    // Databases
    { name: "SQL Server", category: "databases", level: "Expert", color: "from-red-400 to-red-600" },
    { name: "MySQL", category: "databases", level: "Advanced", color: "from-blue-400 to-blue-600" },
    { name: "PostgreSQL", category: "databases", level: "Advanced", color: "from-blue-400 to-indigo-600" },
    { name: "MongoDB", category: "databases", level: "Intermediate", color: "from-green-400 to-green-600" },
    
    // Programming
    { name: "Python", category: "programming", level: "Expert", color: "from-yellow-400 to-blue-500" },
    { name: "R", category: "programming", level: "Advanced", color: "from-blue-400 to-blue-600" },
    { name: "SQL", category: "programming", level: "Expert", color: "from-purple-400 to-purple-600" },
    { name: "C", category: "programming", level: "Intermediate", color: "from-gray-400 to-gray-600" },
    { name: "Java", category: "programming", level: "Intermediate", color: "from-red-400 to-orange-500" },
    
    // Machine Learning
    { name: "Scikit-learn", category: "ml", level: "Advanced", color: "from-orange-400 to-red-500" },
    { name: "TensorFlow", category: "ml", level: "Intermediate", color: "from-orange-400 to-yellow-500" },
    { name: "Pandas", category: "ml", level: "Expert", color: "from-blue-400 to-purple-500" },
    { name: "NumPy", category: "ml", level: "Expert", color: "from-blue-400 to-blue-600" },
    { name: "Matplotlib", category: "ml", level: "Advanced", color: "from-green-400 to-blue-500" },
    
    // Cloud & Tools
    { name: "AWS", category: "cloud", level: "Intermediate", color: "from-orange-400 to-yellow-500" },
    { name: "Azure", category: "cloud", level: "Intermediate", color: "from-blue-400 to-blue-600" },
    { name: "Git", category: "cloud", level: "Advanced", color: "from-red-400 to-red-600" },
    { name: "Docker", category: "cloud", level: "Beginner", color: "from-blue-400 to-cyan-500" },
    
    // Web Development
    { name: "React", category: "web", level: "Advanced", color: "from-cyan-400 to-blue-500" },
    { name: "TypeScript", category: "web", level: "Advanced", color: "from-blue-400 to-blue-600" },
    { name: "Node.js", category: "web", level: "Intermediate", color: "from-green-400 to-green-600" },
    { name: "Tailwind CSS", category: "web", level: "Advanced", color: "from-cyan-400 to-blue-500" }
  ];

  const filteredTechnologies = activeCategory === "all" 
    ? technologies 
    : technologies.filter(tech => tech.category === activeCategory);

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Expert": return "bg-green-500/20 text-green-300 border-green-500/30";
      case "Advanced": return "bg-blue-500/20 text-blue-300 border-blue-500/30";
      case "Intermediate": return "bg-yellow-500/20 text-yellow-300 border-yellow-500/30";
      case "Beginner": return "bg-gray-500/20 text-gray-300 border-gray-500/30";
      default: return "bg-gray-500/20 text-gray-300 border-gray-500/30";
    }
  };

  return (
    <section id="technologies" className="py-20 bg-slate-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Technologies & <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">Skills</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Comprehensive toolkit for data analysis, machine learning, and modern web development
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all duration-300 transform hover:scale-105 ${
                activeCategory === category.id
                  ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white"
                  : "bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10"
              }`}
            >
              <category.icon className="h-5 w-5" />
              {category.name}
            </button>
          ))}
        </div>

        {/* Technologies Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTechnologies.map((tech, index) => (
            <Card key={index} className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-300 transform hover:scale-105 tech-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${tech.color} flex items-center justify-center`}>
                    <span className="text-white font-bold text-lg">
                      {tech.name.substring(0, 2).toUpperCase()}
                    </span>
                  </div>
                  <Badge className={getLevelColor(tech.level)}>
                    {tech.level}
                  </Badge>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{tech.name}</h3>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className={`h-full rounded-full bg-gradient-to-r ${tech.color} transition-all duration-500`}
                    style={{ 
                      width: tech.level === "Expert" ? "95%" : 
                             tech.level === "Advanced" ? "80%" : 
                             tech.level === "Intermediate" ? "65%" : "40%" 
                    }}
                  ></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16">
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">15+</div>
            <div className="text-gray-300">Data Tools</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">8+</div>
            <div className="text-gray-300">Programming Languages</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">5+</div>
            <div className="text-gray-300">ML Frameworks</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-2">10+</div>
            <div className="text-gray-300">Cloud Services</div>
          </div>
        </div>
      </div>
    </section>
  );
}