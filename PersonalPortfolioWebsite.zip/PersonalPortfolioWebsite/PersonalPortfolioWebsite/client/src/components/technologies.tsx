import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Database, 
  Code2, 
  BarChart3, 
  Brain, 
  Server, 
  Palette,
  Terminal,
  Globe,
  Cpu,
  LineChart
} from "lucide-react";

export function Technologies() {
  const [activeCategory, setActiveCategory] = useState("data-analysis");

  const techCategories = {
    "data-analysis": {
      title: "Data Analysis & Visualization",
      icon: BarChart3,
      color: "from-blue-500 to-cyan-500",
      technologies: [
        { name: "Power BI", level: 95, desc: "Advanced dashboard creation, DAX formulas, data modeling", icon: "📊" },
        { name: "SQL", level: 90, desc: "Complex queries, stored procedures, database optimization", icon: "🗃️" },
        { name: "Python", level: 90, desc: "Pandas, NumPy, data manipulation and analysis", icon: "🐍" },
        { name: "Excel", level: 85, desc: "Advanced formulas, pivot tables, VBA macros", icon: "📋" },
        { name: "Tableau", level: 80, desc: "Interactive dashboards and data storytelling", icon: "📈" },
        { name: "R", level: 75, desc: "Statistical analysis and data visualization", icon: "📉" }
      ]
    },
    "machine-learning": {
      title: "Machine Learning & AI",
      icon: Brain,
      color: "from-purple-500 to-pink-500",
      technologies: [
        { name: "Scikit-Learn", level: 90, desc: "Classification, regression, clustering algorithms", icon: "🤖" },
        { name: "TensorFlow", level: 80, desc: "Deep learning and neural networks", icon: "🧠" },
        { name: "PyTorch", level: 75, desc: "Machine learning research and development", icon: "🔥" },
        { name: "Keras", level: 80, desc: "High-level neural networks API", icon: "⚡" },
        { name: "OpenCV", level: 70, desc: "Computer vision and image processing", icon: "👁️" },
        { name: "NLTK", level: 75, desc: "Natural language processing", icon: "💬" }
      ]
    },
    "programming": {
      title: "Programming & Development",
      icon: Code2,
      color: "from-green-500 to-emerald-500",
      technologies: [
        { name: "Python", level: 90, desc: "Advanced programming, OOP, data structures", icon: "🐍" },
        { name: "JavaScript", level: 85, desc: "Modern ES6+, async programming", icon: "🟨" },
        { name: "TypeScript", level: 80, desc: "Type-safe JavaScript development", icon: "🔷" },
        { name: "C++", level: 75, desc: "System programming and algorithms", icon: "⚙️" },
        { name: "Java", level: 70, desc: "Object-oriented programming", icon: "☕" },
        { name: "Git", level: 85, desc: "Version control and collaboration", icon: "🌿" }
      ]
    },
    "web-tech": {
      title: "Web Technologies",
      icon: Globe,
      color: "from-orange-500 to-red-500",
      technologies: [
        { name: "React", level: 85, desc: "Modern component-based UI development", icon: "⚛️" },
        { name: "Next.js", level: 80, desc: "Full-stack React framework", icon: "▲" },
        { name: "Node.js", level: 80, desc: "Server-side JavaScript runtime", icon: "🟢" },
        { name: "HTML5", level: 90, desc: "Semantic markup and accessibility", icon: "🌐" },
        { name: "CSS3", level: 85, desc: "Advanced styling and animations", icon: "🎨" },
        { name: "Tailwind CSS", level: 90, desc: "Utility-first CSS framework", icon: "💨" }
      ]
    },
    "databases": {
      title: "Databases & Cloud",
      icon: Database,
      color: "from-indigo-500 to-purple-500",
      technologies: [
        { name: "MySQL", level: 85, desc: "Relational database design and optimization", icon: "🐬" },
        { name: "PostgreSQL", level: 80, desc: "Advanced SQL and data integrity", icon: "🐘" },
        { name: "MongoDB", level: 75, desc: "NoSQL document database", icon: "🍃" },
        { name: "AWS", level: 70, desc: "Cloud services and deployment", icon: "☁️" },
        { name: "Docker", level: 75, desc: "Containerization and deployment", icon: "🐳" },
        { name: "Firebase", level: 70, desc: "Real-time database and hosting", icon: "🔥" }
      ]
    },
    "tools": {
      title: "Development Tools",
      icon: Terminal,
      color: "from-gray-500 to-slate-500",
      technologies: [
        { name: "Jupyter Notebook", level: 90, desc: "Interactive data analysis environment", icon: "📓" },
        { name: "VS Code", level: 90, desc: "Advanced code editor and debugging", icon: "💻" },
        { name: "PyCharm", level: 85, desc: "Python IDE and debugging", icon: "🔧" },
        { name: "Postman", level: 80, desc: "API testing and development", icon: "📮" },
        { name: "Linux", level: 80, desc: "Command line and system administration", icon: "🐧" },
        { name: "Windows", level: 85, desc: "Desktop application development", icon: "🪟" }
      ]
    }
  };

  const activeData = techCategories[activeCategory as keyof typeof techCategories];
  const IconComponent = activeData.icon;

  return (
    <section id="technologies" className="py-20 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Technology Stack
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Advanced proficiency across the full data science and web development ecosystem
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
          {Object.entries(techCategories).map(([key, category]) => {
            const IconComp = category.icon;
            return (
              <button
                key={key}
                onClick={() => setActiveCategory(key)}
                className={`p-4 rounded-xl transition-all duration-300 ${
                  activeCategory === key
                    ? `bg-gradient-to-r ${category.color} text-white shadow-lg scale-105`
                    : "bg-white hover:bg-gray-50 text-gray-700 hover:scale-102"
                } border border-gray-200`}
              >
                <IconComp className="h-8 w-8 mx-auto mb-2" />
                <div className="text-sm font-medium text-center leading-tight">
                  {category.title.split(" ").map((word, i) => (
                    <div key={i}>{word}</div>
                  ))}
                </div>
              </button>
            );
          })}
        </div>

        <Card className="bg-white/80 backdrop-blur-sm shadow-xl border-0">
          <CardHeader className="text-center pb-8">
            <div className={`w-16 h-16 bg-gradient-to-r ${activeData.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
              <IconComponent className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">
              {activeData.title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {activeData.technologies.map((tech, index) => (
                <div key={index} className="bg-gradient-to-r from-gray-50 to-white p-6 rounded-xl border border-gray-100 hover:shadow-md transition-all duration-300">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{tech.icon}</span>
                      <div>
                        <h4 className="font-semibold text-gray-900 text-lg">{tech.name}</h4>
                        <Badge 
                          className={`mt-1 bg-gradient-to-r ${activeData.color} text-white`}
                        >
                          {tech.level >= 90 ? 'Expert' : tech.level >= 80 ? 'Advanced' : 'Intermediate'}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-gray-900">{tech.level}%</div>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-4 leading-relaxed">{tech.desc}</p>
                  <Progress value={tech.level} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Tech Stack Summary */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Database className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Data Engineering</h3>
            <p className="text-gray-600">ETL pipelines, data warehousing, and big data processing</p>
          </div>
          
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">AI/ML Solutions</h3>
            <p className="text-gray-600">Predictive modeling, neural networks, and intelligent automation</p>
          </div>
          
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <LineChart className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Business Intelligence</h3>
            <p className="text-gray-600">Dashboard creation, KPI tracking, and strategic insights</p>
          </div>
        </div>
      </div>
    </section>
  );
}