import { Code, Wrench, Layers } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export function Skills() {
  const skillCategories = [
    {
      title: "Programming Languages",
      icon: Code,
      color: "text-blue-600",
      skills: [
        { name: "Python", level: 90, proficiency: "Advanced" },
        { name: "SQL", level: 85, proficiency: "Advanced" },
        { name: "C++", level: 70, proficiency: "Intermediate" }
      ]
    },
    {
      title: "Tools & Platforms",
      icon: Wrench,
      color: "text-cyan-600",
      skills: [
        { name: "Power BI", level: 90, proficiency: "Advanced" },
        { name: "Excel", level: 85, proficiency: "Advanced" },
        { name: "MySQL", level: 80, proficiency: "Advanced" },
        { name: "Git/GitHub", level: 75, proficiency: "Intermediate" }
      ]
    },
    {
      title: "Libraries & Frameworks",
      icon: Layers,
      color: "text-green-600",
      skills: [
        { name: "Pandas", level: 90, proficiency: "Advanced" },
        { name: "NumPy", level: 85, proficiency: "Advanced" },
        { name: "Scikit-Learn", level: 85, proficiency: "Advanced" },
        { name: "Matplotlib", level: 75, proficiency: "Intermediate" }
      ]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Technical Skills</h2>
          <p className="text-lg text-gray-600">Comprehensive toolkit for data analysis and machine learning</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <category.icon className={`${category.color} h-8 w-8 mr-3`} />
                <h3 className="text-xl font-semibold text-gray-900">{category.title}</h3>
              </div>
              <div className="space-y-4">
                {category.skills.map((skill, i) => (
                  <div key={i}>
                    <div className="flex justify-between mb-1">
                      <span className="text-gray-700 font-medium">{skill.name}</span>
                      <span className="text-gray-500 text-sm">{skill.proficiency}</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
