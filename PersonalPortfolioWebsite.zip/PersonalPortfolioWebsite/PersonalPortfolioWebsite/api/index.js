// Export the Express app for Vercel serverless functions
import express from 'express';
import { registerRoutes } from '../server/routes.js';

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Register API routes
registerRoutes(app);

export default app;