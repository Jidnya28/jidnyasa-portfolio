# Vercel Deployment Steps for Your Portfolio

## Step 1: Create GitHub Repository
1. Go to GitHub.com and sign in
2. Click "New repository"
3. Name it: `jidnyasa-portfolio`
4. Set to Public
5. Click "Create repository"

## Step 2: Upload Your Code to GitHub
Since you're working in Replit, use these steps:

### Option A: Replit Git Integration
1. In Replit, open the Shell tab
2. Run these commands:
```bash
git init
git add .
git commit -m "Initial portfolio commit"
git remote add origin https://github.com/YOUR_USERNAME/jidnyasa-portfolio.git
git push -u origin main
```

### Option B: Download and Upload
1. Download your Replit project as ZIP
2. Extract the files
3. Upload to your GitHub repository

## Step 3: Deploy to Vercel
1. Go to vercel.com
2. Click "Sign up" and choose "Continue with GitHub"
3. Click "Import Project"
4. Find your `jidnyasa-portfolio` repository
5. Click "Import"

## Step 4: Configure Environment Variables
In Vercel dashboard:
1. Go to Project Settings → Environment Variables
2. Add these variables from your Replit:
   - `DATABASE_URL`: [Your PostgreSQL connection string]
   - `PGHOST`: [Your database host]
   - `PGUSER`: [Your database user]
   - `PGPASSWORD`: [Your database password]
   - `PGDATABASE`: [Your database name]
   - `PGPORT`: [Your database port]

## Step 5: Deploy
1. Click "Deploy"
2. Wait 2-3 minutes for build to complete
3. Your portfolio will be live at: `https://your-project-name.vercel.app`

## Files Added for Vercel Compatibility:
- ✅ `vercel.json` - Deployment configuration
- ✅ `api/index.js` - Serverless function for backend
- ✅ Build scripts already configured in package.json

## Your Portfolio Features (All Ready):
- ✅ Modern dark theme with your professional photo
- ✅ Interactive technology showcase
- ✅ Working contact form with database storage
- ✅ Resume download functionality
- ✅ Mobile responsive design
- ✅ SEO optimized

After deployment, test:
1. Contact form submission
2. Resume download
3. All interactive elements
4. Mobile responsiveness