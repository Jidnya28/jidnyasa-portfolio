# Upload Your Portfolio to GitHub

Since Replit has git restrictions, here's the easiest way to upload your code:

## Method 1: Upload Files Directly (Recommended)

1. **Go to your GitHub repository**: https://github.com/jidnya28/jidnyasa-portfolio.git

2. **Click "uploading an existing file"** (blue link in the quick setup)

3. **Drag and drop these key files** from your Replit file browser:
   - All files in `client/` folder
   - All files in `server/` folder  
   - All files in `shared/` folder
   - `api/` folder (I created this for Vercel)
   - `package.json`
   - `vercel.json`
   - `tailwind.config.ts`
   - `vite.config.ts`
   - `tsconfig.json`
   - `drizzle.config.ts`
   - `postcss.config.js`
   - `attached_assets/` folder (contains your resume and photo)

4. **Add commit message**: "Initial portfolio upload"

5. **Click "Commit changes"**

## Method 2: Download and Upload ZIP

1. In Replit, go to the three dots menu → Download as ZIP
2. Extract the ZIP file on your computer
3. Upload the extracted files to GitHub

## Next Steps After Upload

Once files are uploaded to GitHub:
1. Go to vercel.com
2. Sign up with GitHub
3. Import your `jidnyasa-portfolio` repository
4. Add your database environment variables
5. Deploy!

Your portfolio will be live at: `https://jidnyasa-portfolio.vercel.app`