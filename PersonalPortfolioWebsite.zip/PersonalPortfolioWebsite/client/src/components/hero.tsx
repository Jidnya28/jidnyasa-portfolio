import { Button } from "@/components/ui/button";
import { Mail, Phone, Linkedin, Download, Database, BarChart3, Code2, TrendingUp } from "lucide-react";
import profileImage from "@assets/WhatsApp Image 2025-06-24 at 4.49.02 PM_1750763962016.jpeg";

export function Hero() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="relative min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>
      
      {/* Floating Data Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 animate-float">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-white">
            <Database className="h-6 w-6" />
          </div>
        </div>
        <div className="absolute top-40 right-20 animate-float-delayed">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-white">
            <BarChart3 className="h-6 w-6" />
          </div>
        </div>
        <div className="absolute bottom-40 left-20 animate-float">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-white">
            <Code2 className="h-6 w-6" />
          </div>
        </div>
        <div className="absolute bottom-20 right-10 animate-float-delayed">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-white">
            <TrendingUp className="h-6 w-6" />
          </div>
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-screen">
          <div className="text-white space-y-8">
            <div className="animate-fadeIn">
              <div className="inline-flex items-center bg-gradient-to-r from-purple-600 to-blue-600 rounded-full px-4 py-2 text-sm font-medium mb-6">
                <span className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
                Available for new opportunities
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-bold mb-6">
                <span className="block">Hi, I'm</span>
                <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent animate-gradient">
                  Jidnyasa Patil
                </span>
              </h1>
              
              <div className="text-xl lg:text-2xl text-gray-300 mb-8 leading-relaxed">
                <span className="block mb-2">Data Analyst & ML Engineer</span>
                <span className="text-lg text-gray-400">
                  Transforming raw data into strategic insights with{" "}
                  <span className="text-green-400 font-semibold">99% accuracy</span> and{" "}
                  <span className="text-blue-400 font-semibold">30% faster</span> reporting
                </span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 animate-slideUp">
              <Button 
                onClick={scrollToContact} 
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-3 rounded-full font-semibold transform hover:scale-105 transition-all duration-200"
              >
                <Mail className="mr-2 h-5 w-5" />
                Let's Connect
              </Button>
              <Button 
                size="lg"
                className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-700 hover:to-purple-700 text-white px-8 py-3 rounded-full font-semibold transform hover:scale-105 transition-all duration-200"
                onClick={() => {
                  const link = document.createElement('a');
                  link.href = '/attached_assets/JIDNYASA  Resume_1750686521751.pdf';
                  link.download = 'Jidnyasa_Patil_Resume.pdf';
                  link.click();
                }}
              >
                <Download className="mr-2 h-5 w-5" />
                Download Resume
              </Button>
            </div>
            
            <div className="flex space-x-6 animate-slideUp">
              <a 
                href="mailto:jidnyasa2803@gmail.com" 
                className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-200 hover:scale-110"
              >
                <Mail className="h-5 w-5" />
              </a>
              <a 
                href="https://www.linkedin.com/in/jidnyasa28/" 
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-200 hover:scale-110"
              >
                <Linkedin className="h-5 w-5" />
              </a>
              <a 
                href="tel:+919607531496" 
                className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-all duration-200 hover:scale-110"
              >
                <Phone className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div className="relative animate-slideUp flex justify-center lg:justify-end">
            <div className="relative">
              {/* Profile Image */}
              <div className="w-72 h-72 lg:w-80 lg:h-80 relative mx-auto">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full opacity-20 animate-pulse"></div>
                <div className="absolute inset-2 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full opacity-30"></div>
                <img 
                  src={profileImage} 
                  alt="Jidnyasa Patil" 
                  className="absolute inset-3 w-[calc(100%-24px)] h-[calc(100%-24px)] object-cover rounded-full border-2 border-white/30 shadow-2xl"
                />
                <div className="absolute inset-3 bg-gradient-to-t from-purple-900/10 to-transparent rounded-full"></div>
              </div>
              
              {/* Stats Cards */}
              <div className="grid grid-cols-2 gap-3 mt-8 max-w-sm mx-auto lg:absolute lg:-right-16 lg:top-16 lg:max-w-none">
                <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 lg:p-4 text-center border border-white/20 hover:bg-white/20 transition-all duration-300">
                  <div className="text-2xl lg:text-3xl font-bold text-cyan-400 mb-1">99%</div>
                  <div className="text-xs lg:text-sm text-gray-300">Data Accuracy</div>
                </div>
                <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 lg:p-4 text-center border border-white/20 hover:bg-white/20 transition-all duration-300">
                  <div className="text-2xl lg:text-3xl font-bold text-green-400 mb-1">30%</div>
                  <div className="text-xs lg:text-sm text-gray-300">Time Saved</div>
                </div>
                <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 lg:p-4 text-center border border-white/20 hover:bg-white/20 transition-all duration-300">
                  <div className="text-2xl lg:text-3xl font-bold text-purple-400 mb-1">96%</div>
                  <div className="text-xs lg:text-sm text-gray-300">ML Accuracy</div>
                </div>
                <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 lg:p-4 text-center border border-white/20 hover:bg-white/20 transition-all duration-300">
                  <div className="text-2xl lg:text-3xl font-bold text-pink-400 mb-1">15+</div>
                  <div className="text-xs lg:text-sm text-gray-300">Projects</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
