import { CheckCircle } from "lucide-react";

export function Experience() {
  const experiences = [
    {
      title: "Data Analyst Intern",
      company: "Unified Mentor",
      period: "Jun 2024 – Jul 2024",
      achievements: [
        "Cleaned and processed large datasets, improving data accuracy by 99%",
        "Conducted EDA using MySQL, uncovering key business insights",
        "Developed interactive Power BI dashboards, reducing reporting time by 30%"
      ],
      side: "left"
    },
    {
      title: "Business Analyst Intern",
      company: "Bytegenics Solution Pvt Ltd",
      period: "Jun 2023 – Jul 2023",
      achievements: [
        "Streamlined data collection, reducing processing time by 20%",
        "Implemented automation strategies, boosting productivity by 15%",
        "Collaborated with 3+ cross-functional teams on strategic initiatives",
        "Delivered 15+ detailed reports identifying 10+ strategic trends"
      ],
      side: "right"
    }
  ];

  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Experience</h2>
          <p className="text-lg text-gray-600">Professional journey in data analysis and business intelligence</p>
        </div>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-blue-200 hidden lg:block"></div>
          
          {/* Experience Items */}
          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <div key={index} className={`flex flex-col lg:flex-row ${exp.side === "right" ? "lg:flex-row-reverse" : ""} items-center`}>
                <div className={`lg:w-1/2 ${exp.side === "left" ? "lg:pr-8" : "lg:pl-8"} mb-8 lg:mb-0`}>
                  <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-gray-900">{exp.title}</h3>
                        <p className="text-blue-600 font-medium">{exp.company}</p>
                      </div>
                      <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium">
                        {exp.period}
                      </span>
                    </div>
                    <ul className="space-y-2 text-gray-600">
                      {exp.achievements.map((achievement, i) => (
                        <li key={i} className="flex items-start space-x-2">
                          <CheckCircle className="text-green-600 h-4 w-4 mt-1 flex-shrink-0" />
                          <span dangerouslySetInnerHTML={{ 
                            __html: achievement.replace(/(\d+%)/g, '<strong class="text-green-600">$1</strong>') 
                          }} />
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                {/* Timeline dot */}
                <div className="hidden lg:block relative z-10">
                  <div className="w-4 h-4 bg-blue-600 rounded-full border-4 border-white shadow-lg"></div>
                </div>
                
                <div className={`lg:w-1/2 ${exp.side === "left" ? "lg:pl-8" : "lg:pr-8"}`}></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
