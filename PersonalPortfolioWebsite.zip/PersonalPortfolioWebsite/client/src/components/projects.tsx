import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Shield, Heart, Eye, Github } from "lucide-react";

export function Projects() {
  const projects = [
    {
      title: "Student Performance Prediction",
      description: "Machine learning model predicting academic performance with advanced algorithms.",
      icon: GraduationCap,
      accuracy: "96% Accuracy",
      tech: "Python, Scikit-Learn",
      color: "from-blue-500 to-purple-600",
      features: [
        "Enhanced data quality by 33%",
        "Classification & regression algorithms",
        "Comprehensive performance analysis"
      ]
    },
    {
      title: "Credit Card Fraud Detection",
      description: "Logistic regression model detecting fraudulent transactions with high precision.",
      icon: Shield,
      accuracy: "87% Accuracy",
      tech: "Python, Logistic Regression",
      color: "from-red-500 to-pink-600",
      features: [
        "Reduced false positives by 16%",
        "Handled class imbalance effectively",
        "Optimized model efficiency by 23%"
      ]
    },
    {
      title: "Heart Disease Prediction",
      description: "HIPAA-compliant healthcare solution predicting heart disease risk.",
      icon: Heart,
      accuracy: "91% Accuracy",
      tech: "Python, Healthcare",
      color: "from-green-500 to-teal-600",
      features: [
        "HIPAA-compliant data encryption",
        "Enhanced outcomes by 26%",
        "Ethical data practices"
      ]
    }
  ];

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Featured Projects</h2>
          <p className="text-lg text-gray-600">Machine learning and data analysis projects with measurable impact</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100">
              <div className={`bg-gradient-to-r ${project.color} h-48 flex items-center justify-center`}>
                <project.icon className="text-white h-16 w-16" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{project.title}</h3>
                <p className="text-gray-600 mb-4">{project.description}</p>
                
                <div className="flex items-center justify-between mb-4">
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                    {project.accuracy}
                  </Badge>
                  <span className="text-gray-500 text-sm">{project.tech}</span>
                </div>
                
                <ul className="text-sm text-gray-600 space-y-1 mb-4">
                  {project.features.map((feature, i) => (
                    <li key={i}>• {feature}</li>
                  ))}
                </ul>
                
                <div className="flex space-x-2">
                  <Button size="sm" className="flex-1 bg-blue-600 hover:bg-blue-700">
                    <Eye className="mr-2 h-4 w-4" />
                    View Details
                  </Button>
                  <Button size="sm" variant="outline">
                    <Github className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
