import { GraduationCap, MapPin, Award, Target, Briefcase, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export function About() {
  return (
    <section id="about" className="py-20 bg-gradient-to-br from-white to-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Professional Summary
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-600 to-blue-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Analytical and detail-driven Data Analyst with hands-on experience in Power BI, SQL, and Python 
            for data processing, visualization, and predictive modeling. Proven ability to transform complex 
            datasets into strategic business insights with measurable impact.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Professional Overview */}
          <div className="space-y-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mr-4">
                  <Briefcase className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900">Core Expertise</h3>
              </div>
              
              <div className="space-y-4">
                <p className="text-gray-700 leading-relaxed">
                  I specialize in transforming raw data into actionable business insights that drive strategic decisions. 
                  My expertise encompasses the entire data lifecycle—from collection and cleaning to advanced analytics and visualization.
                </p>
                
                <div className="grid grid-cols-2 gap-3">
                  <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 px-3 py-1">
                    Data Analysis
                  </Badge>
                  <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-100 px-3 py-1">
                    Machine Learning
                  </Badge>
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100 px-3 py-1">
                    Power BI
                  </Badge>
                  <Badge className="bg-cyan-100 text-cyan-700 hover:bg-cyan-100 px-3 py-1">
                    Python & SQL
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-green-600 to-emerald-600 rounded-full flex items-center justify-center mr-4">
                  <Target className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900">Professional Focus</h3>
              </div>
              
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Developing predictive models with high accuracy rates for business forecasting</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Creating interactive dashboards that reduce reporting time and improve decision-making</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Implementing data quality frameworks to ensure 99%+ accuracy in business reporting</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Translating complex business requirements into scalable data solutions</span>
                </li>
              </ul>
            </div>
          </div>
          
          {/* Key Metrics & Info */}
          <div className="space-y-8">
            {/* Impact Metrics */}
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-8 rounded-2xl border border-blue-100">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mr-4">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900">Key Achievements</h3>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-white p-4 rounded-xl text-center">
                  <div className="text-3xl font-bold text-green-600 mb-1">99%</div>
                  <div className="text-sm text-gray-600">Data Accuracy</div>
                </div>
                <div className="bg-white p-4 rounded-xl text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-1">30%</div>
                  <div className="text-sm text-gray-600">Time Reduction</div>
                </div>
                <div className="bg-white p-4 rounded-xl text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-1">96%</div>
                  <div className="text-sm text-gray-600">ML Model Accuracy</div>
                </div>
                <div className="bg-white p-4 rounded-xl text-center">
                  <div className="text-3xl font-bold text-cyan-600 mb-1">15+</div>
                  <div className="text-sm text-gray-600">Projects Completed</div>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <Award className="h-5 w-5 text-yellow-500 mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-gray-800 font-medium">Published IEEE Research Paper</p>
                    <p className="text-gray-600 text-sm">AI-driven surveillance and crime detection systems</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Award className="h-5 w-5 text-yellow-500 mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-gray-800 font-medium">Multiple Industry Certifications</p>
                    <p className="text-gray-600 text-sm">Google Analytics, HackerRank SQL, Data Analytics</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Personal Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
                <GraduationCap className="text-blue-600 h-8 w-8 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">Education</h4>
                <p className="text-sm text-gray-600">BE Computer Science & Engineering</p>
                <p className="text-sm text-gray-600">Data Science Specialization</p>
                <Badge className="mt-2 bg-green-100 text-green-700 hover:bg-green-100">
                  CGPA: 8.66/10
                </Badge>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
                <MapPin className="text-green-600 h-8 w-8 mb-3" />
                <h4 className="font-semibold text-gray-900 mb-2">Location</h4>
                <p className="text-sm text-gray-600">Mumbai, India</p>
                <p className="text-sm text-gray-600">Open to Remote Work</p>
                <Badge className="mt-2 bg-blue-100 text-blue-700 hover:bg-blue-100">
                  Available
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
