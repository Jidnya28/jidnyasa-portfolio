import { GraduationCap, Award, ExternalLink, Book } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function Education() {
  const certifications = [
    {
      name: "Google Analytics Certification",
      description: "Web analytics and data insights",
      icon: "🔍",
      bgColor: "bg-blue-100"
    },
    {
      name: "HackerRank SQL Certification",
      description: "Advanced SQL skills and database management",
      icon: "💻",
      bgColor: "bg-green-100"
    },
    {
      name: "Data Analytics & Visualization Job Simulation",
      description: "Practical data analysis and visualization skills",
      icon: "📊",
      bgColor: "bg-purple-100"
    }
  ];

  return (
    <section id="education" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Education & Certifications</h2>
          <p className="text-lg text-gray-600">Academic background and professional certifications</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Education */}
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-8 rounded-2xl">
            <div className="flex items-center mb-6">
              <GraduationCap className="text-blue-600 h-8 w-8 mr-4" />
              <h3 className="text-2xl font-semibold text-gray-900">Education</h3>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Bachelor of Engineering
              </h4>
              <p className="text-blue-600 font-medium mb-2">Computer Science and Engineering (Data Science)</p>
              <p className="text-gray-600 mb-2">University of Mumbai</p>
              <p className="text-gray-500 text-sm mb-4">06/2020 to 05/2024</p>
              
              <div className="flex items-center justify-between mb-4">
                <span className="text-gray-700 font-medium">CGPA</span>
                <Badge className="bg-green-100 text-green-700 hover:bg-green-100">8.66/10</Badge>
              </div>
              
              <div>
                <p className="text-gray-700 font-medium mb-2">Relevant Coursework:</p>
                <div className="flex flex-wrap gap-2">
                  {["Machine Learning", "Data Mining", "Business Intelligence", "Python Programming", "Artificial Intelligence"].map((course) => (
                    <Badge key={course} variant="secondary" className="bg-blue-100 text-blue-700">
                      {course}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="mt-6 bg-white p-6 rounded-xl shadow-sm">
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Honors</h4>
              <p className="text-blue-600 font-medium">Artificial Intelligence and Machine Learning</p>
              <p className="text-gray-600 text-sm">Specialized honors program focusing on advanced AI/ML concepts</p>
            </div>
          </div>
          
          {/* Certifications */}
          <div>
            <div className="flex items-center mb-6">
              <Award className="text-cyan-600 h-8 w-8 mr-4" />
              <h3 className="text-2xl font-semibold text-gray-900">Certifications</h3>
            </div>
            
            <div className="space-y-4">
              {certifications.map((cert, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4">
                      <div className={`w-12 h-12 ${cert.bgColor} rounded-lg flex items-center justify-center text-xl`}>
                        {cert.icon}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">{cert.name}</h4>
                        <p className="text-gray-600 text-sm">{cert.description}</p>
                      </div>
                    </div>
                    <ExternalLink className="text-gray-400 hover:text-blue-600 cursor-pointer h-5 w-5" />
                  </div>
                </div>
              ))}
            </div>
            
            {/* Publication */}
            <div className="mt-8">
              <div className="flex items-center mb-4">
                <Book className="text-gray-700 h-6 w-6 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">Publications</h3>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <h4 className="font-semibold text-gray-900 mb-2">
                  Cop Connect AI driven Surveillance and Sketch Generation for Crime
                </h4>
                <p className="text-blue-600 font-medium mb-2">IEEE INDIA Com 2024</p>
                <p className="text-gray-600 text-sm mb-3">
                  International Conference on "Computing for Sustainable Global Development"
                </p>
                <div className="flex items-center space-x-4">
                  <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100">
                    Published
                  </Badge>
                  <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
                    <ExternalLink className="mr-1 h-4 w-4" />
                    View Publication
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
