import { Mail, Linkedin, Phone } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">JP</span>
              </div>
              <span className="font-semibold text-lg">Jidnyasa Patil</span>
            </div>
            <p className="text-gray-400 mb-4">
              Data Analyst passionate about transforming data into actionable insights.
            </p>
            <div className="flex space-x-4">
              <a href="mailto:jidnyasa2803@gmail.com" className="text-gray-400 hover:text-white transition-colors">
                <Mail className="h-5 w-5" />
              </a>
              <a href="https://www.linkedin.com/in/jidnyasa28/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="tel:+919607531496" className="text-gray-400 hover:text-white transition-colors">
                <Phone className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <div className="space-y-2">
              <a href="#about" className="block text-gray-400 hover:text-white transition-colors">About</a>
              <a href="#experience" className="block text-gray-400 hover:text-white transition-colors">Experience</a>
              <a href="#projects" className="block text-gray-400 hover:text-white transition-colors">Projects</a>
              <a href="#skills" className="block text-gray-400 hover:text-white transition-colors">Skills</a>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Skills</h4>
            <div className="space-y-2 text-gray-400">
              <p>Python & SQL</p>
              <p>Power BI & Excel</p>
              <p>Machine Learning</p>
              <p>Data Visualization</p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 Jidnyasa Patil. All rights reserved. | Built with modern web technologies.
          </p>
        </div>
      </div>
    </footer>
  );
}
