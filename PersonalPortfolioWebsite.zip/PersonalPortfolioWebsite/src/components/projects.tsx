import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ExternalLink, Github, BarChart3, Brain, Database, TrendingUp } from "lucide-react";

export function Projects() {
  const projects = [
    {
      title: "Sales Performance Dashboard",
      description: "Comprehensive Power BI dashboard analyzing sales performance across multiple regions with real-time KPI tracking and predictive forecasting.",
      technologies: ["Power BI", "SQL Server", "DAX", "Excel"],
      highlights: ["30% faster reporting", "99% data accuracy", "Real-time insights"],
      icon: BarChart3,
      color: "from-blue-500 to-purple-600"
    },
    {
      title: "Customer Churn Prediction",
      description: "Machine learning model to predict customer churn using Python and scikit-learn, achieving 85% accuracy with actionable insights for retention strategies.",
      technologies: ["Python", "Scikit-learn", "Pandas", "Matplotlib"],
      highlights: ["85% prediction accuracy", "20% churn reduction", "Cost savings analysis"],
      icon: Brain,
      color: "from-green-500 to-blue-600"
    },
    {
      title: "Supply Chain Analytics",
      description: "End-to-end analytics solution for supply chain optimization using SQL and Python, identifying bottlenecks and improving efficiency by 25%.",
      technologies: ["SQL", "Python", "Tableau", "PostgreSQL"],
      highlights: ["25% efficiency gain", "Cost optimization", "Automated reporting"],
      icon: Database,
      color: "from-purple-500 to-pink-600"
    },
    {
      title: "Financial Forecasting Model",
      description: "Time series forecasting model for financial planning using advanced statistical methods and machine learning algorithms.",
      technologies: ["R", "Python", "Time Series", "Statistics"],
      highlights: ["95% forecast accuracy", "Risk assessment", "Strategic planning"],
      icon: TrendingUp,
      color: "from-orange-500 to-red-600"
    }
  ];

  return (
    <section id="projects" className="py-20 bg-slate-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            Featured <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">Projects</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Showcasing impactful data analysis projects that drive business value and decision-making
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <Card key={index} className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-300 transform hover:scale-[1.02] group">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-4 mb-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${project.color} flex items-center justify-center`}>
                    <project.icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-xl text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-purple-400 group-hover:to-blue-400 transition-all duration-300">
                      {project.title}
                    </CardTitle>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <p className="text-gray-300 leading-relaxed">
                  {project.description}
                </p>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-semibold text-white mb-2">Key Achievements</h4>
                    <div className="flex flex-wrap gap-2">
                      {project.highlights.map((highlight, idx) => (
                        <Badge 
                          key={idx}
                          className="bg-green-500/20 text-green-300 border-green-500/30"
                        >
                          {highlight}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-semibold text-white mb-2">Technologies Used</h4>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech, idx) => (
                        <Badge 
                          key={idx}
                          variant="secondary"
                          className="bg-white/10 text-gray-300 border-white/20"
                        >
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-3 pt-4">
                  <Button 
                    size="sm"
                    className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                    onClick={() => {
                      const element = document.getElementById("contact");
                      if (element) element.scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Learn More
                  </Button>
                  <Button 
                    size="sm"
                    variant="outline"
                    className="border-white/20 text-white hover:bg-white/10"
                    onClick={() => {
                      const element = document.getElementById("contact");
                      if (element) element.scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    <Github className="mr-2 h-4 w-4" />
                    Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-16">
          <Card className="bg-gradient-to-r from-purple-600/10 to-blue-600/10 border-purple-500/30 backdrop-blur-sm max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-4">Interested in My Work?</h3>
              <p className="text-gray-300 mb-6">
                I'd love to discuss how my data analysis expertise can contribute to your organization's success.
              </p>
              <Button 
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-6 py-2"
                onClick={() => {
                  const element = document.getElementById("contact");
                  if (element) element.scrollIntoView({ behavior: "smooth" });
                }}
              >
                Get In Touch
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}