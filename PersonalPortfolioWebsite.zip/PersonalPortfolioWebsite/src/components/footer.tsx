import { Mail, Phone, Linkedin, Github, Heart } from "lucide-react";

export function Footer() {
  const socialLinks = [
    {
      name: "Email",
      href: "mailto:jidnyasa.patil@email.com",
      icon: Mail
    },
    {
      name: "Phone",
      href: "tel:+15551234567",
      icon: Phone
    },
    {
      name: "LinkedIn",
      href: "https://linkedin.com/in/jidnyasa-patil",
      icon: Linkedin
    },
    {
      name: "GitHub",
      href: "https://github.com/jidnyasa-patil",
      icon: Github
    }
  ];

  const quickLinks = [
    { name: "About", href: "#about" },
    { name: "Technologies", href: "#technologies" },
    { name: "Projects", href: "#projects" },
    { name: "Contact", href: "#contact" }
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-slate-900 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <h3 className="text-2xl font-bold text-white mb-2">
                Jidnyasa Patil
              </h3>
              <p className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 font-medium">
                Data Analyst & Machine Learning Enthusiast
              </p>
            </div>
            <p className="text-gray-300 mb-6 max-w-md">
              Transforming complex data into actionable insights with expertise in Power BI, 
              SQL, Python, and Machine Learning. Ready to drive your business forward with 
              data-driven solutions.
            </p>
            <div className="flex gap-4">
              {socialLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  target={link.href.startsWith('http') ? '_blank' : undefined}
                  rel={link.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="w-10 h-10 bg-white/10 hover:bg-gradient-to-r hover:from-purple-600 hover:to-blue-600 rounded-lg flex items-center justify-center text-gray-300 hover:text-white transition-all duration-300 transform hover:scale-110"
                  aria-label={link.name}
                >
                  <link.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <button
                    onClick={() => scrollToSection(link.href)}
                    className="text-gray-300 hover:text-white transition-colors duration-300 text-left"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Skills Summary */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Core Skills</h4>
            <ul className="space-y-2 text-gray-300">
              <li>Power BI & Tableau</li>
              <li>SQL & Database Design</li>
              <li>Python & R Programming</li>
              <li>Machine Learning</li>
              <li>Statistical Analysis</li>
              <li>Data Visualization</li>
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-white/10 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-gray-300 text-sm">
              © {new Date().getFullYear()} Jidnyasa Patil. All rights reserved.
            </div>
            <div className="flex items-center gap-2 text-gray-300 text-sm">
              <span>Built with</span>
              <Heart className="h-4 w-4 text-red-400" />
              <span>using React, TypeScript & Tailwind CSS</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}