import { Button } from "./ui/button";
import { Mail, Phone, Linkedin, Download, Database, BarChart3, Code2, TrendingUp } from "lucide-react";

export function Hero() {
  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const downloadResume = () => {
    const link = document.createElement('a');
    link.href = '/resume.pdf';
    link.download = 'Jidnyasa_Patil_Resume.pdf';
    link.click();
  };

  return (
    <section id="hero" className="relative min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute top-40 left-40 w-80 h-80 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>
      
      {/* Floating Data Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 animate-float">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-white">
            <Database className="h-6 w-6" />
          </div>
        </div>
        <div className="absolute top-40 right-20 animate-float">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-white">
            <BarChart3 className="h-6 w-6" />
          </div>
        </div>
        <div className="absolute bottom-40 left-20 animate-float">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-white">
            <Code2 className="h-6 w-6" />
          </div>
        </div>
        <div className="absolute bottom-20 right-10 animate-float">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 text-white">
            <TrendingUp className="h-6 w-6" />
          </div>
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-screen">
          <div className="text-white space-y-8">
            <div className="animate-fadeIn">
              <div className="inline-flex items-center bg-gradient-to-r from-purple-600 to-blue-600 rounded-full px-4 py-2 text-sm font-medium mb-6">
                <span className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
                Available for Data Analyst Opportunities
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-bold mb-6">
                <span className="block">Jidnyasa</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">
                  Patil
                </span>
              </h1>
              
              <p className="text-xl lg:text-2xl text-gray-300 mb-8 leading-relaxed">
                Data Analyst transforming complex datasets into actionable insights with 
                <span className="text-blue-400 font-semibold"> Power BI</span>, 
                <span className="text-purple-400 font-semibold"> SQL</span>, and 
                <span className="text-cyan-400 font-semibold"> Python</span>
              </p>
              
              <div className="flex flex-wrap gap-4 mb-8">
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg px-4 py-2">
                  <Database className="h-5 w-5 text-blue-400" />
                  <span className="text-sm">99% Data Accuracy</span>
                </div>
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg px-4 py-2">
                  <BarChart3 className="h-5 w-5 text-purple-400" />
                  <span className="text-sm">30% Faster Reporting</span>
                </div>
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-lg px-4 py-2">
                  <TrendingUp className="h-5 w-5 text-cyan-400" />
                  <span className="text-sm">15+ ML Models</span>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={scrollToContact}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-3 rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
              >
                <Mail className="mr-2 h-5 w-5" />
                Get In Touch
              </Button>
              
              <Button 
                onClick={downloadResume}
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 px-8 py-3 rounded-lg font-medium transition-all duration-300"
              >
                <Download className="mr-2 h-5 w-5" />
                Download Resume
              </Button>
            </div>
            
            <div className="flex gap-6 pt-8">
              <a 
                href="mailto:jidnyasa.patil@email.com"
                className="text-gray-400 hover:text-white transition-colors duration-300 transform hover:scale-110"
              >
                <Mail className="h-6 w-6" />
              </a>
              <a 
                href="tel:+1234567890"
                className="text-gray-400 hover:text-white transition-colors duration-300 transform hover:scale-110"
              >
                <Phone className="h-6 w-6" />
              </a>
              <a 
                href="https://linkedin.com/in/jidnyasa-patil"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors duration-300 transform hover:scale-110"
              >
                <Linkedin className="h-6 w-6" />
              </a>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative w-80 h-80 mx-auto">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full blur-2xl opacity-30 animate-pulse"></div>
              <div className="relative w-full h-full bg-gradient-to-br from-purple-500 to-blue-500 rounded-full p-2">
                <div className="w-full h-full bg-gray-800 rounded-full flex items-center justify-center">
                  <div className="w-64 h-64 bg-gradient-to-br from-purple-400 to-blue-400 rounded-full flex items-center justify-center text-white font-bold text-2xl">
                    JP
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}