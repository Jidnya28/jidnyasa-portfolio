import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { TrendingUp, Users, Award, Target } from "lucide-react";

export function About() {
  const achievements = [
    {
      icon: TrendingUp,
      title: "99% Data Accuracy",
      description: "Maintained exceptional data quality standards across all projects"
    },
    {
      icon: Users,
      title: "15+ Stakeholders",
      description: "Successfully collaborated with cross-functional teams"
    },
    {
      icon: Award,
      title: "30% Efficiency Gain",
      description: "Improved reporting processes through automation"
    },
    {
      icon: Target,
      title: "10+ ML Models",
      description: "Developed and deployed predictive analytics solutions"
    }
  ];

  const skills = [
    "Power BI", "SQL", "Python", "Machine Learning", "Data Visualization",
    "Statistical Analysis", "ETL Processes", "Dashboard Development",
    "Predictive Modeling", "Business Intelligence"
  ];

  return (
    <section id="about" className="py-20 bg-slate-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
            About <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">Me</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Passionate Data Analyst with expertise in transforming complex data into actionable business insights
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div className="space-y-6">
            <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Professional Summary</CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300 space-y-4">
                <p>
                  Experienced Data Analyst with a strong background in statistical analysis, machine learning, 
                  and business intelligence. Specialized in creating comprehensive dashboards and reports that 
                  drive data-driven decision making across organizations.
                </p>
                <p>
                  Proficient in modern data tools including Power BI, SQL, Python, and advanced analytics 
                  platforms. Proven track record of improving business processes through data automation 
                  and predictive modeling.
                </p>
                <p>
                  Currently seeking opportunities to leverage my analytical skills and technical expertise 
                  to contribute to innovative data-driven solutions in a dynamic organization.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Core Competencies</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill, index) => (
                    <Badge 
                      key={index}
                      variant="secondary"
                      className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 text-white border-purple-500/30"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {achievements.map((achievement, index) => (
              <Card key={index} className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
                <CardContent className="p-6 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full mb-4">
                    <achievement.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">{achievement.title}</h3>
                  <p className="text-gray-300 text-sm">{achievement.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="text-center">
          <Card className="bg-gradient-to-r from-purple-600/10 to-blue-600/10 border-purple-500/30 backdrop-blur-sm max-w-4xl mx-auto">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-4">Ready to Transform Your Data?</h3>
              <p className="text-gray-300 mb-6">
                Let's collaborate to unlock insights from your data and drive meaningful business outcomes 
                through advanced analytics and machine learning solutions.
              </p>
              <div className="flex justify-center gap-4">
                <Badge className="bg-purple-600/20 text-purple-300 border-purple-500/30">Data Analysis</Badge>
                <Badge className="bg-blue-600/20 text-blue-300 border-blue-500/30">Machine Learning</Badge>
                <Badge className="bg-cyan-600/20 text-cyan-300 border-cyan-500/30">Business Intelligence</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}