import { Route, Router } from 'wouter'
import Home from './pages/home'
import NotFound from './pages/not-found'

function App() {
  return (
    <Router>
      <Route path="/" component={Home} />
      <Route path="*" component={NotFound} />
    </Router>
  )
}

export default App